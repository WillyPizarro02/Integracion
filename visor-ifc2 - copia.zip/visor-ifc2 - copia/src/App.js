// src/App.js
import React, { useState } from 'react';
import './App.css';
import ModelViewer from './components/ModelViewer';
import ModelSelector from './components/ModelSelector';

function App() {
  const [currentModelUrl, setCurrentModelUrl] = useState('');

  const handleSelectModel = (modelUrl) => {
    setCurrentModelUrl(modelUrl);
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Visor de Modelos 3D</h1>
      </header>
      <main className="App-main">
        <ModelSelector onSelectModel={handleSelectModel} />
        {currentModelUrl ? (
          <ModelViewer modelUrl={currentModelUrl} />
        ) : (
          <div className="no-model-message">
            Selecciona un modelo para visualizar
          </div>
        )}
      </main>
      <footer className="App-footer">
        <p>Visor GLB/GLTF © 2025</p>
      </footer>
    </div>
  );
}

export default App;