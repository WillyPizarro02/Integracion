// src/services/api.js
const API_URL = 'http://localhost:8080/api/models';

export const fetchModelsList = async () => {
  try {
    const response = await fetch(`${API_URL}/list`);
    if (!response.ok) {
      throw new Error('Error al obtener la lista de modelos');
    }
    return await response.json();
  } catch (error) {
    console.error('Error:', error);
    //modelo por defecto
    return ['result'];
  }
};

export const getModelUrl = (modelName) => {
  return `${API_URL}/${modelName}`;
};