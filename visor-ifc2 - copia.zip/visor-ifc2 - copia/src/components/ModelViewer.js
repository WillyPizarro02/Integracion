// src/components/ModelViewer.js
import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';

function ModelViewer({ modelUrl }) {
  const mountRef = useRef(null);
  const [loadingStatus, setLoadingStatus] = useState('idle');
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!modelUrl || !mountRef.current) return;

    // Limpiar cualquier renderizado previo
    while (mountRef.current.firstChild) {
      mountRef.current.removeChild(mountRef.current.firstChild);
    }

    setLoadingStatus('loading');
    console.log('Cargando modelo desde:', modelUrl);

    // Configuración básica
    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight;
    
    // Escena
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf0f0f0);
    
    // Cámara
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(2, 2, 5); // Posición inicial de la cámara más alejada
    
    // Renderizador
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mountRef.current.appendChild(renderer.domElement);
    
    // Controles
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.25;
    controls.screenSpacePanning = false;
    controls.maxPolarAngle = Math.PI / 1.5;
    controls.minDistance = 1;
    controls.maxDistance = 50;
    
    // Iluminación mejorada
    // Luz ambiental
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    
    // Luz direccional principal con sombras
    const mainLight = new THREE.DirectionalLight(0xffffff, 1);
    mainLight.position.set(10, 10, 10);
    mainLight.castShadow = true;
    // Configurar sombras
    mainLight.shadow.mapSize.width = 1024;
    mainLight.shadow.mapSize.height = 1024;
    mainLight.shadow.camera.near = 0.1;
    mainLight.shadow.camera.far = 100;
    mainLight.shadow.camera.left = -10;
    mainLight.shadow.camera.right = 10;
    mainLight.shadow.camera.top = 10;
    mainLight.shadow.camera.bottom = -10;
    scene.add(mainLight);
    
    // Luz direccional de relleno
    const fillLight = new THREE.DirectionalLight(0xffffff, 0.5);
    fillLight.position.set(-5, 5, -5);
    scene.add(fillLight);
    
    // Añadir una cuadrícula para referencia, pero más pequeña y sutil
    const gridHelper = new THREE.GridHelper(10, 20, 0x888888, 0xcccccc);
    gridHelper.material.opacity = 0.5;
    gridHelper.material.transparent = true;
    scene.add(gridHelper);
    
    // Añadir un plano con material para mostrar sombras
    const planeGeometry = new THREE.PlaneGeometry(20, 20);
    const planeMaterial = new THREE.MeshStandardMaterial({ 
      color: 0xffffff,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.5,
      roughness: 1 
    });
    const plane = new THREE.Mesh(planeGeometry, planeMaterial);
    plane.rotation.x = -Math.PI / 2;
    plane.position.y = -0.01;
    plane.receiveShadow = true;
    scene.add(plane);
    
    // Cargador GLTF
    const loader = new GLTFLoader();
    
    // Función de progreso
    const onProgress = (xhr) => {
      if (xhr.lengthComputable) {
        const percentComplete = (xhr.loaded / xhr.total) * 100;
        console.log(`${Math.round(percentComplete)}% cargado`);
      }
    };
    
    // Cargar el modelo
    loader.load(
      modelUrl,
      (gltf) => {
        try {
          // Preparar el modelo
          const model = gltf.scene;
          
          // Habilitar sombras para todos los objetos
          model.traverse((node) => {
            if (node.isMesh) {
              node.castShadow = true;
              node.receiveShadow = true;
            }
          });
          
          // Añadir el modelo a la escena
          scene.add(model);
          
          // Calcular el tamaño y centro del modelo
          const box = new THREE.Box3().setFromObject(model);
          const size = box.getSize(new THREE.Vector3());
          const center = box.getCenter(new THREE.Vector3());
          
          console.log('Tamaño del modelo:', size);
          console.log('Centro del modelo:', center);
          
          // Centrar el modelo en el origen
          model.position.x = -center.x;
          model.position.y = -center.y;
          model.position.z = -center.z;
          
          // Ajustar la escala para que el modelo se vea bien
          // Encontramos la dimensión más grande
          const maxDim = Math.max(size.x, size.y, size.z);
          
          // Solo escalamos si el modelo es muy pequeño o muy grande
          if (maxDim < 0.1 || maxDim > 20) {
            const scale = 2 / maxDim;
            console.log('Aplicando escala:', scale);
            model.scale.multiplyScalar(scale);
          }
          
          // Ajustar la cámara para ver el modelo completo
          // Recalcular el bounding box después de escalar
          const newBox = new THREE.Box3().setFromObject(model);
          const newSize = newBox.getSize(new THREE.Vector3());
          const newCenter = newBox.getCenter(new THREE.Vector3());
          
          // Calcular la distancia ideal de la cámara
          const fov = camera.fov * (Math.PI / 180);
          const maxSize = Math.max(newSize.x, newSize.y, newSize.z);
          let cameraZ = Math.abs(maxSize / Math.sin(fov / 2));
          
          // Añadir un poco de margen
          cameraZ *= 1.5;
          
          // Posicionar la cámara para ver el modelo completo
          const direction = new THREE.Vector3(1, 1, 1).normalize();
          camera.position.copy(newCenter).add(direction.multiplyScalar(cameraZ));
          camera.lookAt(newCenter);
          
          // Actualizar los controles para que orbiten alrededor del centro del modelo
          controls.target.copy(newCenter);
          controls.update();
          
          console.log('Modelo cargado con éxito');
          setLoadingStatus('success');
        } catch (err) {
          console.error('Error procesando el modelo:', err);
          setError('Error procesando el modelo');
          setLoadingStatus('error');
        }
      },
      onProgress,
      (err) => {
        console.error('Error cargando el modelo:', err);
        setError('Error cargando el modelo');
        setLoadingStatus('error');
      }
    );
    
    // Bucle de animación
    const animate = () => {
      requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    
    animate();
    
    // Manejo responsivo
    const handleResize = () => {
      if (!mountRef.current) return;
      
      const width = mountRef.current.clientWidth;
      const height = mountRef.current.clientHeight;
      
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    
    window.addEventListener('resize', handleResize);
    
    // Limpieza
    return () => {
      window.removeEventListener('resize', handleResize);
      
      // Liberar recursos de Three.js
      scene.clear();
      renderer.dispose();
      
      // Limpiar el canvas
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
    };
  }, [modelUrl]);

  return (
    <div style={{ position: 'relative', width: '100%', height: '600px' }}>
      {loadingStatus === 'loading' && (
        <div style={{
          position: 'absolute',
          top: '10px',
          left: '10px',
          background: 'rgba(0,0,0,0.7)',
          color: 'white',
          padding: '5px 10px',
          borderRadius: '4px',
          zIndex: 100
        }}>
          Cargando modelo...
        </div>
      )}
      
      {loadingStatus === 'error' && (
        <div style={{
          position: 'absolute',
          top: '10px',
          left: '10px',
          background: 'rgba(255,0,0,0.7)',
          color: 'white',
          padding: '5px 10px',
          borderRadius: '4px',
          zIndex: 100
        }}>
          {error || 'Error al cargar el modelo'}
        </div>
      )}
      
      <div 
        ref={mountRef} 
        style={{ 
          width: '100%', 
          height: '100%', 
          borderRadius: '8px',
          overflow: 'hidden',
          boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
        }} 
      />
    </div>
  );
}

export default ModelViewer;