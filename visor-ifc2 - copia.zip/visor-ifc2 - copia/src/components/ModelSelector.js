// src/components/ModelSelector.js
import React, { useEffect, useState, useCallback } from 'react';
import { fetchModelsList, getModelUrl } from '../services/api';

function ModelSelector({ onSelectModel }) {
  const [models, setModels] = useState([]);
  const [selectedModel, setSelectedModel] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Usar useCallback para evitar regeneraciones innecesarias
  const selectModel = useCallback((model) => {
    console.log("Seleccionando modelo:", model);
    setSelectedModel(model);
    onSelectModel(getModelUrl(model));
  }, [onSelectModel]);

  // Cargar modelos
  useEffect(() => {
    let isMounted = true;
    
    const loadModels = async () => {
      try {
        setLoading(true);
        const modelsList = await fetchModelsList();
        console.log("Modelos recibidos:", modelsList);
        
        if (!isMounted) return;
        
        if (modelsList && modelsList.length > 0) {
          setModels(modelsList);
          
          // Si no hay un modelo seleccionado o el seleccionado no está en la lista,
          // seleccionar el primero
          if (!selectedModel || !modelsList.includes(selectedModel)) {
            selectModel(modelsList[0]);
          }
        } else {
          setModels([]);
        }
        setError(null);
      } catch (err) {
        console.error("Error al cargar modelos:", err);
        if (isMounted) {
          setError('Error al cargar la lista de modelos');
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    loadModels();
    
    return () => {
      isMounted = false;
    };
  }, [selectModel, selectedModel]);

  // Manejar cambio de selección
  const handleModelChange = (e) => {
    e.preventDefault(); // Prevenir comportamiento por defecto
    const selected = e.target.value;
    console.log("Modelo seleccionado desde dropdown:", selected);
    selectModel(selected);
  };

  // Formatear nombre para mostrar
  const getDisplayName = (fileName) => {
    if (!fileName) return 'Desconocido';
    
    // Extraer el nombre base sin extensión
    const lastDotIndex = fileName.lastIndexOf('.');
    const extension = lastDotIndex > 0 ? fileName.substring(lastDotIndex).toLowerCase() : '';
    const baseName = lastDotIndex > 0 ? fileName.substring(0, lastDotIndex) : fileName;
    
    // Determinar tipo de modelo
    const modelType = extension === '.glb' ? ' (GLB)' : extension === '.gltf' ? ' (GLTF)' : '';
    
    // Formatear nombre
    const formattedName = baseName
      .replace(/[_-]/g, ' ')
      .replace(/([A-Z])/g, ' $1')
      .trim();
    
    return formattedName.charAt(0).toUpperCase() + formattedName.slice(1) + modelType;
  };

  if (loading) {
    return <div>Cargando modelos...</div>;
  }

  if (error) {
    return <div style={{ color: 'red' }}>{error}</div>;
  }

  if (models.length === 0) {
    return <div>No hay modelos disponibles</div>;
  }

  return (
    <div style={{ marginBottom: '20px' }}>
      <label htmlFor="model-select" style={{ marginRight: '10px', fontWeight: 'bold' }}>
        Seleccionar modelo:
      </label>
      <select
        id="model-select"
        value={selectedModel}
        onChange={handleModelChange}
        style={{
          padding: '8px 12px',
          borderRadius: '4px',
          border: '1px solid #ccc',
          fontSize: '16px',
          minWidth: '200px'
        }}
      >
        {models.map((model, index) => (
          <option key={`model-${index}`} value={model}>
            {getDisplayName(model)}
          </option>
        ))}
      </select>
      
      {/* Información adicional para depuración */}
      <div style={{ fontSize: '12px', color: '#666', marginTop: '5px' }}>
        Modelo seleccionado: {selectedModel}
      </div>
    </div>
  );
}

export default ModelSelector;