package pe.gob.mef.dgpmi.dseip.ped.gateway.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import pe.gob.mef.dgpmi.dseip.ped.gateway.dto.RouteDto;

import java.util.Map;

@Data
@Configuration
@RefreshScope
@ConfigurationProperties(prefix = "ped")
@PropertySource(value = "classpath:ped-routes.yml", factory =  YamlPropertySourceFactory.class)
public class PedRoutesProperties {
    private Map<String, RouteDto> routes;
}
