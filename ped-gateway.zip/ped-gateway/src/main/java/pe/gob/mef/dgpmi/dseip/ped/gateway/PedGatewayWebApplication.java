package pe.gob.mef.dgpmi.dseip.ped.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PedGatewayWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(PedGatewayWebApplication.class, args);
	}

}
