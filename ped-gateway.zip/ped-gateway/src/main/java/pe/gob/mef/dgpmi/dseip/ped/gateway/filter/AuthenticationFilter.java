package pe.gob.mef.dgpmi.dseip.ped.gateway.filter;

import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import pe.gob.mef.dgpmi.dseip.ped.gateway.config.PedRoutesProperties;
import pe.gob.mef.dgpmi.dseip.ped.gateway.dto.RouteDto;
import pe.gob.mef.dgpmi.dseip.ped.gateway.util.JwtUtil;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

@Component
@Slf4j
public class AuthenticationFilter extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {

    @Autowired
    private RouteValidator validator;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PedRoutesProperties pedRoutesProperties;

    public AuthenticationFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        log.info("into AuthenticationFilter.apply for valid URL");
        return ((exchange, chain) -> {
            if (validator.isSecured.test(exchange.getRequest())) {
                //header contains token or not
                if (!exchange.getRequest().getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
                    throw new RuntimeException("missing authorization header");
                }

                String authHeader = exchange.getRequest().getHeaders().get(HttpHeaders.AUTHORIZATION).get(0);
                if (authHeader != null && authHeader.startsWith("Bearer ")) {
                    authHeader = authHeader.substring(7);
                }

                try {
//                    //REST call to AUTH service
//                    template.getForObject("http://IDENTITY-SERVICE//validate?token" + authHeader, String.class);
                    jwtUtil.validateToken(authHeader);

                    Claims claims = jwtUtil.extractAllClaims(authHeader);

                    String path = exchange.getRequest().getURI().toString();

                    boolean allowed = hasRoles(claims.get("roles").toString(), path);
                    log.info("value allowed : {}", allowed);

                    if (!allowed) {
                        throw new RuntimeException("resource not allowed");
                    }

                    // String roles = getRolesConfig(path);
                    // log.info("value roles of config : {}", roles);

                } catch (Exception e) {
                    log.info("error: {}", e.getMessage());
                    log.info("invalid access...!");
                    throw new RuntimeException("un authorized access to application");
                }
            }
            return chain.filter(exchange);
        });
    }

    public static class Config {

    }

    private boolean hasRoles(String rolesClaim, String url) {
        boolean allowedResource = false;
        String rolesConfig = getRolesConfig(url);
        log.info("rolesConfig = {}; rolesClaim = {}", rolesConfig, rolesClaim);
        if (!rolesConfig.isEmpty() && !rolesClaim.isEmpty()) {

            String[] result = Arrays.stream(rolesClaim.split(","))
                    .filter(a -> Arrays.asList(rolesConfig.split(",")).contains(a))
                    .toArray(String[]::new);

            log.info("result = {}", result);

            if (result.length > 0) {
                allowedResource = true;
            }

        }
        return allowedResource;
    }

    private String getRolesConfig(String url) {
        Map<String, RouteDto> routes = pedRoutesProperties.getRoutes();

        log.info("method getRolesConfig value url : {}", url);
        String roles = "";
        Optional<RouteDto> route = routes
                .values()
                .stream()
                .filter(x -> url.endsWith(x.getUrl()))
                .findFirst();

        if (route.isPresent()) {
            roles = route.get().getRoles();
        }

        return roles;
    }
}
