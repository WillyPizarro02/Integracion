package pe.gob.mef.dgpmi.dseip.ped.gateway.dto;

import lombok.Data;

@Data
public class RouteDto {
    private String id;
    private String url;
    private String roles;
}
