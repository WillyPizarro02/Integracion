package pe.gob.mef.dgpmi.dseip.ped.gateway.filter;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.function.Predicate;

@Component
public class RouteValidator {
    public static final List<String> openApiEndpoints = List.of(
            "/ped-autorizacion-servicio/auth/token",
            "/ped-seguridad-servicio/utils/captchaImage",
            "/ped-seguridad-servicio/usuario/validar",
            "/ped-seguridad-servicio/entidad/buscar"
    );

    public Predicate<ServerHttpRequest> isSecured =
            request -> openApiEndpoints
                    .stream()
                    .noneMatch(uri -> request.getURI().getPath().contains(uri));
}
